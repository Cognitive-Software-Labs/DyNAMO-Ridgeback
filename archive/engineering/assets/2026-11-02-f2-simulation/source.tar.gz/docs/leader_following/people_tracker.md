# People tracker

The `people_tracker` ROS node combines camera person detections, registered
D455 depth and front/rear lidar detections into planar constant-velocity Kalman
tracks. It publishes `leader_follow/people` using the
[People interface](architecture.md#messages). Candidate selection and simulation
evidence are owned by the [benchmark reference](benchmarks.md).

## Sensor contract

All topics are relative to the robot namespace, normally `r100_0001`.

| Input | Default topic |
|---|---|
| RGB | `sensors/camera_0/color/image` |
| Registered metric depth | `sensors/camera_0/depth/image` |
| Color intrinsics | `sensors/camera_0/color/camera_info` |
| Front lidar | `sensors/lidar2d_0/scan` |
| Rear lidar | `sensors/lidar2d_1/scan` |
| Transforms | namespaced `tf` and `tf_static` |

RGB and depth must have the same optical frame and dimensions, matching color
intrinsics, rectified pinhole geometry, and at most 40 ms timestamp skew.
Supported encodings are RGB/BGR/RGBA/BGRA 8-bit color and `32FC1` metres or
`16UC1` millimetres for depth. Unregistered hardware depth must be registered
upstream; changing its frame label is not registration.

The node chooses the newest queued RGB frame with a complete synchronized
input bundle and sensor-to-output TF at that frame's stamp. Sensor/TF callbacks
continue while camera inference runs; fusion updates remain serialized. Depth, intrinsics and both scans come from
that timestamp or earlier, within the sensor-age limit. Each lidar uses TF at
its own scan stamp. There is no fallback to a latest transform at an unrelated
time. The queue contains up to 30 messages per input.

F1 recordings include warmup messages and a transient-local static TF
subscription with enough history for multiple publishers. Sensor readiness
requires a complete camera/lidar-to-odometry tree. The F2 corpus additionally
checks freshness and transforms at every evaluation tick.

## Measurement and fusion

The detector returns image boxes and confidence. The central torso portion of
each box supplies a median valid depth, excluding background near box edges.
At least 12 valid pixels between 0.15 and 15 m are required. Color intrinsics
back-project the box centre, and recorded/live TF transforms it to the output
frame. Measurement variance uses depth-dependent uncertainty and the median
absolute depth deviation, with a 4 cm minimum standard deviation.

Each lidar is processed with its native angle/range metadata. Its detections
are transformed into the common output frame, then merged with a 25 cm overlap
suppression radius. This preserves the two sensors' separate origins and blind
sectors; the learned adapters run on native scans rather than assuming a
co-located polar sensor. This detection-level merge supplies the planned
360-degree lidar coverage.

A camera detection can create a person track. Lidar observations can refine or
sustain an existing camera-confirmed track; lidar clusters alone cannot create
people. The filter predicts `[x, y, vx, vy]`, associates each sensor's measurements
once per tick using gated Hungarian assignment, and updates uncertainty with
the Joseph covariance form. ByteTrack image IDs prefer compatible camera assignments without bypassing the
position gate. Its low-confidence preset follows the selected detector score
scale; the benchmark reference records the preset. Camera updates precede lidar
updates. Unobserved
tracks persist internally only until expiry and are not emitted as detections.
IDs are stable within an association session; they are not appearance identity
and may change after expiry or a simulator clock reset.

The node publishes positions and velocities in the `People.header.frame_id`,
normally `odom`. `appearance` remains empty: learned identity embeddings and
leader confirmation belong to F3. Consequently the existing `leader_identity`
node cannot confirm a lock from these messages alone. This node publishes no
motion commands.

If input/TF becomes stale, the node emits empty `People` messages after 150 ms
of advancing ROS time. A paused simulator clock does not advance this timeout.
A reset starts a new track session.

## Runtime

Build and source the workspace, prepare the candidate dependencies/checkpoints
using the [benchmark workflow](benchmarks.md#candidate-environments), then run:

```bash
ros2 launch ridgeback_leader_follow people_tracker.launch.py namespace:=r100_0001 use_sim_time:=true model_dir:="$PWD/artifacts/leader-following/f2-models"
```

`RIDGEBACK_PERCEPTION_VENV` selects the compute interpreter; otherwise the
launch uses `perception_venv` under the current workspace. `device:=cpu` permits
a CPU camera run. Benchmark-only TensorFlow and the separate MOT environment
are unnecessary for a selected runtime that does not use those adapters.
Prepare weights before running without network access.

| Parameter | Default | Meaning |
|---|---|---|
| `camera_candidate` | `owlv2` | Selected quality-first camera; `rfdetr` is the faster alternative |
| `lidar_candidate` | `lfe-ppn` | Selected native-scan adapter, bounded CPU thread pools |
| `model_dir` | `artifacts/leader-following/f2-models` | Model storage and adjacent pinned vendor sources |
| `device` | `cuda` | Camera/compatible lidar compute device; LFE-PPN and legacy adapters use CPU |
| `output_frame` | `odom` | Position and velocity frame |
| `maximum_sensor_age` | `0.075` | Maximum preceding-input age, seconds |
| `association_gate` | `0.75` | Maximum position association distance, metres |
| `track_maximum_age` | `0.75` | Unobserved-track expiry, seconds |
| `rgb_topic`, `depth_topic`, `camera_info_topic` | above | Camera topic overrides |
| `front_scan_topic`, `rear_scan_topic` | above | Raw scan topic overrides |

The selected camera favors detection quality over latency; offline scores do
not establish a real-time deadline. Dense crowds still cause association errors.
The robot/Thor runtime and performance checks remain pending until hardware
access. The current path is a stationary-observer simulation tracker; it does
not certify camera calibration, latency, collision avoidance or closed-loop
following on hardware.
