# Leader-following crowd simulation

This reference owns the F1 crowd scenes and their qualification. The
[FOLLOWING plan](../plans/FOLLOWING_leader_in_crowds.md) owns subsequent
people tracking, leader recognition and closed-loop following work.

## Scene set

Every scene lasts 20 seconds in a shared corridor. World coordinates are
metres, Z-up, with the floor at z=0 and the observation Ridgeback at the
origin facing +X. The robot remains stationary during F1.

| Scenario | People | Motion |
|---|---|---|
| `leader_alone` | 1 | Leader walks straight, turns left and stops |
| `crossing` | 2 | Bystander crosses the sightline between robot and leader |
| `lookalike_parallel` | 2 | An identically dressed person walks beside the leader |
| `lookalike_crossing` | 2 | Leader and look-alike cross the same path at different times, avoiding body overlap |
| `leader_stop` | 4 | Leader approaches and stops among three standing people |
| `crowd` | 3, 5 or 9 | Leader with 2, 4 or 8 bystanders walking in adjacent lanes |

`crowd_scenarios.py` owns waypoint positions, durations and identities. Path
interpolation is linear; heading follows the current segment and persists at
a stop. The path's travelled distance drives the two-second gait cycle at
0.5 m per animation second, so a stationary person does not keep walking in
place. All instances use the same textured human: identical appearance is
deliberate for the look-alike scenarios. This is a controlled synthetic asset
set, not a claim about appearance diversity or performance on real people.

## Pedestrian asset

The character is **Cesium Man**, © 2017 Cesium, CC-BY-4.0, from the pinned
Khronos glTF Sample Assets source. The original binary, upstream license,
[attribution and conversion notice](../../src/ridgeback_leader_follow/sim/assets/cesium_man/NOTICE.md),
source revision and SHA-256 conversion receipt are tracked beside the asset.

`sim/prepare_human.py` runs under Blender 4.2.9 to produce the Gazebo Collada
skin/animation and 48 evaluated mesh frames for Isaac from that one source.
The character is scaled to 1.75 m and seated on the floor. Blender is needed
only to regenerate assets; normal launches use the committed outputs.

Gazebo's native `CrowdMotion` system sets the actor's trajectory pose and
animation time on each simulation update. Isaac updates the corresponding
world transform and sampled skinned mesh on its simulation thread. These are
animated, textured humans rather than the earlier box proxies. They are
scripted actors: they do not react to the robot or other pedestrians, and do
not implement physical human collision response. Following and avoidance
performance belong to later phases.

## Robot and sensor boundary

Gazebo includes the existing Clearpath `robot_spawn` bringup. Isaac reuses the
committed Ridgeback USD, `RidgebackRig`, `RosIO`, and production camera/lidar
bindings, with a generated `robot_state_publisher` description. Neither path
starts frontier exploration, Nav2 or a following controller. No F1 code
publishes a robot velocity command. Isaac consumes no external drive commands;
Gazebo's standard command path remains present on the private simulation domain.

The robot configuration is copied from `clearpath/robot.yaml` into each run's
`setup/` directory. Existing host or hardware configurations are not edited.
Pedestrians remain at their initial pose until valid RGB, aligned depth,
camera calibration, both lidar scans, raw odometry and static transforms have
arrived. Readiness uses actual messages, not a fixed startup delay.

Under `/r100_0001/`, the monitored topics are:

- `sensors/camera_0/color/image` and `color/camera_info`;
- `sensors/camera_0/depth/image`;
- `sensors/lidar2d_0/scan` and `sensors/lidar2d_1/scan`;
- `platform/odom/filtered` in Gazebo, `platform/odom` in Isaac, plus `tf` and `tf_static`.

Both backends use the production 640×480 D455 profile and dual UST-10LX
sensors. Isaac uses ideal aligned geometric depth for this F1 baseline.
Simulator time drives motion and stamps. Scenario time excludes startup and
sensor warmup. Rendering and rasterized gait can differ between engines;
their shared trajectory contract is independent of pixel-level rendering.

## Run a scene

From the workspace root, install the simulation dependency profiles and build
as described in the root README. The optional Gazebo plugin is built when
`gz-sim8` development libraries are present; the ordinary leader identity
node can still be built without Gazebo. Isaac requires the complete pinned
`isaac_venv`. Build after adding the new modules and executable:

```bash
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install --base-paths src --packages-select ridgeback_leader_follow
source install/setup.bash

ros2 run ridgeback_leader_follow crowd_scene --backend gz --scenario crossing --gui
isaac_venv/bin/python3 -m ridgeback_leader_follow.crowd_runner --backend isaac --scenario crossing --gui
```

Omit `--gui` for headless runs. `--scenario` accepts the six names above;
`--crowd-size 2|4|8` selects the bystander count for `crowd`. `--duration 1`
shortens a smoke test; durations must be multiples of 0.05 s up to 20 s.
`--output-dir <new-directory>` selects an evidence directory; existing
directories are refused. `--record` also writes the monitored sensor topics
to a SQLite ROS bag, including latched static transforms for replay.

Each standalone scene chooses a private ROS domain unless `--ros-domain N`
is specified; the manifest records it. Gazebo also uses a unique transport
partition. All child processes belong to the run and are stopped on completion
or interruption. `ROS_LOG_DIR` overrides are preserved. Headless stepping is
unthrottled by the F1 runner; GUI mode is paced at no more than real time.

## Ground truth and artifacts

Runs default to `artifacts/leader-following/<unique-run>/`:

| Artifact | Contents |
|---|---|
| `manifest.json` | Scenario, domain, duration, input hashes, base revision and completion/failure |
| `ground_truth.csv` | Every person's identity, role, observed world position/yaw, simulator/scenario time and separate commanded pose/time |
| `sensor_health.json` | Valid message counts, run counts, stamps, image encoding/shape and scan frame/bin information |
| `camera_info.json` | Camera calibration and optical frame |
| `frames/` | RGB PNGs, depth NPZs and front/rear scan JSON at 0, 6, 10, 14 and 19 s |
| `source/`, `simulation_inputs/`, `launch_inputs/` | Preserved Python, native plugin, human assets and launch inputs, including the plugin binary |
| `setup/`, `package.diff` | Run-local robot configuration/generated state and tracked package diff |
| `sensors/` | Optional sensor ROS bag |
| `scene.sdf` / `final_scene.usda` | Generated Gazebo world / final Isaac stage |

Truth is sampled at 20 Hz. Gazebo reads the actor-origin world pose multiplied
by the observed `TrajectoryPose` component, exactly as the renderer does;
Isaac reads world transforms from the live stage after updating. Commands are
logged separately and never substituted for observed positions. Ground truth
does not publish `People` messages or enter leader recognition. A complete
F1 run establishes scene playback and data availability, not detector accuracy,
identity retention, collision avoidance or following success.

## Qualification

```bash
ros2 run ridgeback_leader_follow qualify_crowd
# Or qualify one backend at a time, with explicit isolated domains:
ros2 run ridgeback_leader_follow qualify_crowd --backends gz --ros-domain 87
ros2 run ridgeback_leader_follow qualify_crowd --backends isaac --ros-domain 88
```

`ISAAC_PYTHON` can select a non-default Isaac environment. `--output-root`
selects a fresh qualification directory and `--record` enables bags for every
scene. Qualification runs eight configurations per backend: the five
non-density scenes and all three crowd sizes. Each case must exit cleanly,
report completion, log every person for the full duration without gaps over
75 ms, preserve finite world poses matching its path within 5 mm/rad, and
provide live camera/depth/calibration, both scans, odometry and static TF.
It also requires a representative RGB frame and nearby front-lidar returns
in the initial pedestrian sector. `qualification.json` records per-case results;
an interrupted or failed case cannot produce a passing matrix.

Inspect representative camera, depth and scan snapshots as part of review;
automated message counts alone do not establish that the intended people are
visible. F1 has no ten-repetition following-performance claim: that protocol
applies when tracking and control exist in later phases.

## Qualification result

All eight configurations per backend passed the F1 gates: six scenario
families with the crowd family exercised at all three densities. The sixteen
20-second runs recorded every person at 20 Hz, alongside live robot sensors.
Results are scene/data qualification only; F2–F4 performance remains untested.
The saved reports are `artifacts/leader-following/f1-gazebo-filtered/qualification.json`
and `artifacts/leader-following/f1-isaac-qualification/qualification.json`.
Run backends sequentially: simultaneous cold starts can time out the vendor
controller activation. Use an unused ROS domain to avoid unrelated publishers.
