#!/usr/bin/env python3
"""Exercise the real People publisher with isolated recorded sensor playback."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time
import rclpy
from leader_follow_interfaces.msg import People
from ridgeback_leader_follow.crowd_runner import stop_process


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('run','output','python','model-dir'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--ros-domain',type=int,required=True)
    p.add_argument('--camera',default='yolo11')
    p.add_argument('--lidar',default='clustering')
    a=p.parse_args();os.environ['ROS_DOMAIN_ID']=str(a.ros_domain)
    a.output.mkdir(parents=True,exist_ok=False)
    qos=a.output/'qos.yaml'
    qos.write_text('/r100_0001/tf_static:\n  reliability: reliable\n  durability: transient_local\n  history: keep_all\n')
    rclpy.init();node=rclpy.create_node('f2_people_validation');messages=[]
    def receive(msg):
        messages.append({'sim_time':msg.header.stamp.sec+msg.header.stamp.nanosec*1e-9,'frame':msg.header.frame_id,
            'people':[{'track_id':v.id,'x':v.position.x,'y':v.position.y,'vx':v.velocity.x,'vy':v.velocity.y,
                       'confidence':v.confidence,'appearance':list(v.appearance)} for v in msg.people]})
    node.create_subscription(People,'/r100_0001/leader_follow/people',receive,100)
    processes=[]
    with (a.output/'console.log').open('w') as log:
        try:
            from ament_index_python.packages import get_package_prefix
            executable=Path(get_package_prefix('ridgeback_leader_follow'))/'lib/ridgeback_leader_follow/people_tracker'
            tracker=subprocess.Popen([str(a.python),str(executable),'--ros-args','-r','__ns:=/r100_0001',
                '-r','/tf:=tf','-r','/tf_static:=tf_static','-p','use_sim_time:=true',
                '-p',f'model_dir:={a.model_dir.resolve()}','-p',f'camera_candidate:={a.camera}','-p',f'lidar_candidate:={a.lidar}'],
                stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            processes.append(tracker)
            deadline=time.monotonic()+60
            while not node.count_publishers('/r100_0001/leader_follow/people'):
                rclpy.spin_once(node,timeout_sec=.1)
                if tracker.poll() is not None:raise RuntimeError('Tracker startup failed')
                if time.monotonic() > deadline:raise TimeoutError('People publisher discovery timed out')
            playback=subprocess.Popen(['ros2','bag','play',str(a.run/'sensors'),'--rate','.5','--clock','100',
                '--qos-profile-overrides-path',str(qos),'--disable-keyboard-controls'],
                stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            processes.append(playback)
            deadline=time.monotonic()+180
            while playback.poll() is None:
                rclpy.spin_once(node,timeout_sec=.02)
                if tracker.poll() is not None:raise RuntimeError('Tracker exited during sensor playback')
                if time.monotonic() > deadline:raise TimeoutError('Sensor playback timed out')
            for _ in range(20):rclpy.spin_once(node,timeout_sec=.05)
            if playback.returncode:raise RuntimeError('Sensor playback failed')
        finally:
            for process in reversed(processes):stop_process(process)
            node.destroy_node();rclpy.shutdown()
    (a.output/'people.jsonl').write_text(''.join(json.dumps(m)+'\n' for m in messages))
    if not messages or not any(m['people'] for m in messages):raise ValueError('No nonempty People messages')
    if any(m['frame'] != 'odom' for m in messages):raise ValueError('Incorrect People frame')
    (a.output/'validation.json').write_text(json.dumps({'status':'passed','messages':len(messages),
        'nonempty_messages':sum(bool(m['people']) for m in messages),'domain':a.ros_domain,
        'camera':a.camera,'lidar':a.lidar,'scope':'real ROS node, sensors/TF from bag, People publication; no motion command'},indent=2)+'\n')


if __name__ == '__main__':main()
