import numpy as np
import pytest
from ridgeback_leader_follow.fusion import Measurement, PeopleFusion, depth_in_color, box_measurement


def test_lidar_does_not_invent_people_and_keeps_confirmed_id():
    fusion=PeopleFusion()
    assert fusion.update(0.,[Measurement(2,0,.04,.5,'lidar')]) == []
    first=fusion.update(.1,[Measurement(2,0,.04,.9,'camera')])[0]
    seen=fusion.update(.2,[Measurement(2.1,0,.02,.7,'lidar')])[0]
    assert seen.identity == first.identity
    assert 2 < seen.state[0] < 2.1
    assert seen.state[2] > 0
    assert np.linalg.eigvalsh(seen.covariance).min() > 0
    assert fusion.update(.3,[]) == []
    assert fusion.update(1.2,[Measurement(2.2,0,.02,.7,'lidar')]) == []


def test_depth_registration_baseline_and_nearest_surface():
    k=np.array([[10,0,0],[0,10,0],[0,0,1]])
    depth=np.ones((4,4))*2
    matrix=np.eye(4); matrix[0,3]=.2
    registered=depth_in_color(depth,k,k,(4,4),matrix)
    assert np.isinf(registered[:,0]).all()
    assert np.allclose(registered[:,1:],2)


def test_box_depth_invalid_rejected_and_metric_projection():
    k=np.array([[10,0,5],[0,10,5],[0,0,1]])
    depth=np.full((20,20),np.inf)
    assert box_measurement([0,0,20,20],.8,depth,k,np.eye(4)) is None
    depth[:]=2
    m=box_measurement([0,0,20,20],.8,depth,k,np.eye(4))
    assert (m.x,m.y) == (1.,1.)
    with pytest.raises(ValueError): Measurement(0,0,-1,.5,'camera')
    fusion=PeopleFusion(); fusion.update(1,[])
    with pytest.raises(ValueError): fusion.update(1,[])


def test_camera_identity_cue_preserves_crossing_but_cannot_teleport():
    fusion=PeopleFusion()
    first=fusion.update(0.,[Measurement(0,0,.04,.9,'camera',camera_id=10),
                            Measurement(.4,0,.04,.9,'camera',camera_id=20)])
    original={t.camera_id:t.identity for t in first}
    crossing=fusion.update(.1,[Measurement(.3,0,.04,.9,'camera',camera_id=10),
                               Measurement(.1,0,.04,.9,'camera',camera_id=20)])
    assert {t.camera_id:t.identity for t in crossing} == original
    far=fusion.update(.2,[Measurement(4,0,.04,.9,'camera',camera_id=10)])
    assert far[0].identity != original[10]
