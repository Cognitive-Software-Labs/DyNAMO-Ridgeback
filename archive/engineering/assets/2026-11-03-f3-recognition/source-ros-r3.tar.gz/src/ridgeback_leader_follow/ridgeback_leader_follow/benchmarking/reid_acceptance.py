"""Review F3 case evidence; missing camera-exit coverage is never a pass."""
import argparse
import csv
import json
from pathlib import Path
from .lock_metrics import score_locks
from .reid import CANDIDATES
from .dataset import SensorBag
from .stationary_anchor import align_records


def review(root,output):
    corpus=json.loads((root/'corpus.json').read_text())
    cases=corpus['results'];checks={}
    checks['sixteen_qualified_f3_cases']=(corpus.get('status')=='passed' and len(cases)==16
                                       and corpus.get('scene_profile')=='f3')
    checks['five_complete_candidate_comparisons']=all(
        (root/'comparison'/candidate/Path(case['run']).name/'score.json').exists()
        for candidate in CANDIDATES for case in cases)
    models={}
    for folder in sorted((root/'lock').glob('*')):
        if not folder.is_dir():continue
        results=[]
        for case in cases:
            run=Path(case['run']);key=run.name
            predictions=folder/key/'lock.jsonl'
            complete=folder/key/'score.json'
            if not predictions.exists() or not complete.exists():continue
            truth={}
            with (run/'ground_truth.csv').open() as stream:
                for row in csv.DictReader(stream):
                    truth.setdefault(round(float(row['scenario_time']),6),[]).append(row)
            annotations={round(row['scenario_time'],6):row for row in
                         (json.loads(line) for line in (root/'annotations'/(key+'.jsonl')).read_text().splitlines())}
            records=[json.loads(line) for line in predictions.read_text().splitlines()]
            if len(records)!=len(annotations):raise ValueError(f'Incomplete lock or annotation data: {key}')
            records=align_records(records,SensorBag(run),annotations)
            results.append({'case':key,**score_locks(records,truth,annotations)})
        models[folder.name]={'cases':results,'checks':{
            'complete_integrated_cases':len(results)==len(cases),
            'correct_leader_lock_in_every_case':len(results)==len(cases) and all(r['correct_locked_frames']>0 for r in results),
            'no_wrong_locks':bool(results) and all(r['wrong_locked_frames']==0 for r in results),
            'outside_camera_test_coverage':sum(r['outside_camera_frames'] or 0 for r in results)>0,
            'holds_correct_identity_outside_camera':sum(r['outside_camera_frames'] or 0 for r in results)>0 and
                all(r['outside_camera_frames']==r['correct_locked_outside_camera_frames'] for r in results)}}
    result={'status':'review_required','automatic_qualification':False,'checks':checks,'models':models,
            'policy':'Report all acceptance evidence; no automatic declaration that F3 is finished. No-wrong-lock is an additional conservative engineering check.',
            'scope':'simulation recognition; no robot movement or target hardware qualification'}
    output.write_text(json.dumps(result,indent=2)+'\n')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();review(args.root,args.output)


if __name__ == '__main__':main()
