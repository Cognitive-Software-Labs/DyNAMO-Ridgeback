"""Regression for the asynchronous RGB-D/TF backlog seen in bag playback."""
import struct
import pytest
from types import SimpleNamespace
from sensor_msgs.msg import Image,CameraInfo
from rclpy.time import Time
from ridgeback_leader_follow.people_tracker_node import PeopleTrackerNode
from ridgeback_leader_follow.benchmarking.dataset import stamp


def test_tick_uses_newest_complete_bundle_when_latest_rgb_is_unpaired():
    def image(at,encoding,data):
        msg=Image();msg.header.stamp=Time(nanoseconds=round(at*1e9)).to_msg()
        msg.header.frame_id='camera';msg.width=msg.height=1
        msg.encoding=encoding;msg.step=len(data);msg.data=data
        return msg
    older=image(1.95,'rgb8',b'\0\0\0');newer=image(2.,'rgb8',b'\0\0\0')
    depth=image(1.95,'32FC1',struct.pack('<f',1.))
    calls=[];processed=[];published=[]
    def prepare(rgb):
        calls.append(stamp(rgb))
        if stamp(rgb) > 1.99:raise ValueError('Depth has not arrived for latest RGB')
        return depth,CameraInfo(),None,[],[]
    node=SimpleNamespace(appearance_encoder=None,queues={'rgb':[older,newer]},last_rgb=1.9,last_output=1.9,
        output_frame='odom',get_clock=lambda:SimpleNamespace(now=lambda:Time(seconds=2)),
        prepare_inputs=prepare,get_logger=lambda:SimpleNamespace(warning=lambda *a,**k:None),
        fusion=SimpleNamespace(stamp=1.9,update=lambda at,measurements:processed.append(at) or []),
        detector=SimpleNamespace(detect=lambda pixels:[]),image_association=SimpleNamespace(update=lambda boxes,shape:[]),lidars={},
        publisher=SimpleNamespace(publish=published.append))
    PeopleTrackerNode.tick(node)
    assert calls == pytest.approx([2.,1.95])
    assert processed == pytest.approx([1.95])
    assert len(published) == 1
    assert stamp(published[0]) == pytest.approx(1.95)
