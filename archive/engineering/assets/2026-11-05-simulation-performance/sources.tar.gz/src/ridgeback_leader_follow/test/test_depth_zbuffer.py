"""Depth-alignment optimization must preserve nearest surfaces and stable ties."""
import runpy
from pathlib import Path
import numpy as np


def test_linear_zbuffer_matches_sorted_reference_with_ties_and_holes():
    root=Path(__file__).resolve().parents[3]
    nearest=runpy.run_path(str(root/'src/ridgeback_autonomy_isaac/sim/isaac/sensors.py'))['_nearest_depth_sources']
    random=np.random.default_rng(42)
    for count in (0,1,100,10000):
        target=random.integers(0,1000,count)
        source=np.arange(count)
        z=random.integers(1,10,count).astype(np.float32)
        pixels,chosen=nearest(target,source,z,max(1000,count))
        order=np.lexsort((z,target));reference=target[order]
        expected_pixels,first=np.unique(reference,return_index=True)
        np.testing.assert_array_equal(pixels,expected_pixels)
        np.testing.assert_array_equal(chosen,source[order][first])
