"""Offline regression checks for geometric assumptions and qualification gates."""

import math
import numpy as np
import pytest
from model import roller_geometry
from run import cases, evaluate


def test_rollers_fit_declared_wheel_envelope():
    radius, width = 0.0759, 0.079
    p, rho, _, _ = roller_geometry(radius, width)
    # Local X is a roller's axle; orient it 45 degrees from the wheel axle.
    axis = np.array([1, 1, 0]) / math.sqrt(2)
    other = np.array([-1, 1, 0]) / math.sqrt(2)
    wheel_points = (
        p[:, 0, None] * axis
        + p[:, 1, None] * other
        + p[:, 2, None] * [0, 0, 1]
        + [0, 0, rho]
    )
    assert np.max(np.linalg.norm(wheel_points[:, [0, 2]], axis=1)) <= radius + 1e-12
    assert np.max(np.abs(wheel_points[:, 1])) <= width / 2
    assert np.max(np.linalg.norm(wheel_points[:, [0, 2]], axis=1)) == pytest.approx(
        radius
    )


def samples(velocity=(0.1, 0, 0), sensor_error=0.0):
    return [
        dict(
            position=[velocity[0] * t, velocity[1] * t, 0.03],
            body_velocity=list(velocity),
            yaw=velocity[2] * t,
            time=t,
            sensor_error=sensor_error,
            sensor_translation_error=sensor_error,
            sensor_rotation_error=0.0,
            linear_velocity=[*velocity[:2], 0.0],
            lowest_z=0.0,
            floor_penetration=0.0,
            targets=[0] * 4,
        )
        for t in np.linspace(0, 5, 151)
    ]


def test_linear_gate_rejects_wrong_direction_and_cross_drift():
    case = dict(kind="linear", command=[0.1, 0, 0])
    assert evaluate(case, samples(), [])["passed"]
    assert not evaluate(case, samples((-0.1, 0, 0)), [])["passed"]
    assert not evaluate(case, samples((0.1, 0.03, 0)), [])["passed"]


def test_sensor_detachment_cannot_pass_motion_gate():
    assert not evaluate(
        dict(kind="linear", command=[0.1, 0, 0]), samples(sensor_error=0.002), []
    )["passed"]


def test_full_matrix_has_both_directions_and_contact_orientations():
    matrix = cases()
    assert sum(c["kind"] == "linear" for c in matrix) == 8
    assert sum(c["kind"] == "rotate" for c in matrix) == 2
    assert sum(c["kind"] == "wall" for c in matrix) == 3
    assert len({c["name"] for c in matrix}) == len(matrix)


def test_timeout_does_not_pass_a_robot_still_moving():
    assert not evaluate(dict(kind="timeout"), samples(), [])["passed"]
